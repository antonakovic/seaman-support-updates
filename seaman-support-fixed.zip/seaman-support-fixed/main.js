const { app, BrowserWindow, dialog } = require('electron');
const path = require('path');
const { startServer, stopServer } = require('./server');

let mainWindow;
let serverInstance;
let allowQuit = false;
const PORT = 3741;

async function createWindow() {
  try {
    serverInstance = await startServer(PORT);
  } catch (error) {
    dialog.showErrorBox('Server error', error.message || String(error));
    app.quit();
    return;
  }

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 650,
    title: 'SEAMAN SUPPORT',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  await mainWindow.loadURL(`http://localhost:${PORT}`);

  mainWindow.on('close', async (event) => {
    if (allowQuit) return;

    event.preventDefault();

    const result = await dialog.showMessageBox(mainWindow, {
      type: 'question',
      title: 'Έξοδος',
      message: 'Θέλεις να λύσεις τους ζυγούς;',
      buttons: ['Μαρς', 'Στο καιρό'],
      defaultId: 0,
      cancelId: 1,
      noLink: true
    });

    if (result.response === 0) {
      allowQuit = true;
      mainWindow.close();
    }
  });

  mainWindow.on('closed', async () => {
    mainWindow = null;
    await stopServer(serverInstance);
    app.quit();
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', async () => {
  await stopServer(serverInstance);
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', async () => {
  await stopServer(serverInstance);
});
