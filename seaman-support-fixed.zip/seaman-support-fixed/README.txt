SEAMAN SUPPORT - ELECTRON APP

ΤΙ ΕΙΝΑΙ
- Τοπική desktop εφαρμογή Windows με Electron.
- Έχει login / create account.
- Αποθηκεύει δεδομένα στο data/database.json.
- Όταν κλείσεις το παράθυρο της εφαρμογής, σταματά και ο local server.

ΠΡΩΤΗ ΕΚΚΙΝΗΣΗ ΓΙΑ ΔΟΚΙΜΗ
1. Εγκατέστησε Node.js v22.
2. Άνοιξε τον φάκελο seaman-support-electron.
3. Κάνε διπλό κλικ στο start-dev.bat.
4. Θα ανοίξει η εφαρμογή ως desktop παράθυρο.

BUILD ΓΙΑ ΝΑ ΒΓΕΙ .EXE
1. Κάνε διπλό κλικ στο build-exe.bat.
2. Όταν τελειώσει, θα δημιουργηθεί φάκελος dist.
3. Εκεί θα βρεις portable .exe.

ΓΙΑ ΚΙΝΗΤΟ ΣΤΟ ΙΔΙΟ WIFI
Όσο η desktop εφαρμογή είναι ανοιχτή, ο server τρέχει στην πόρτα 3741.
Από κινητό στο ίδιο δίκτυο άνοιξε:
http://IP-ΤΟΥ-ΥΠΟΛΟΓΙΣΤΗ:3741

ΣΗΜΑΝΤΙΚΟ BACKUP
Πριν αντικαταστήσεις έκδοση, κράτα backup το:
data/database.json
