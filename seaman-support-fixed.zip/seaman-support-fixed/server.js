const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-local-secret-seaman-support';
const isPackaged = process.resourcesPath && process.resourcesPath.includes('resources');

const dataDir = isPackaged
  ? path.join(process.resourcesPath, 'data')
  : path.join(__dirname, 'data');

const dbFile = path.join(dataDir, 'database.json');

function ensureDatabase() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  if (!fs.existsSync(dbFile)) {
    fs.writeFileSync(
      dbFile,
      JSON.stringify({ users: [], tasks: [] }, null, 2),
      'utf8'
    );
  }
}

function readDb() {
  ensureDatabase();
  return JSON.parse(fs.readFileSync(dbFile, 'utf8'));
}

function writeDb(db) {
  ensureDatabase();
  fs.writeFileSync(dbFile, JSON.stringify(db, null, 2), 'utf8');
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Δεν είσαι συνδεδεμένος.' });
  }

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Η σύνδεση έληξε. Κάνε ξανά sign in.' });
  }
}

function isMeaningfulChange(reqBody, previousTask) {
  const editFields = [
    'type',
    'date',
    'status',
    'operatorName',
    'service',
    'phone',
    'hostname',
    'username',
    'ticket',
    'description'
  ];

  return editFields.some((field) => {
    if (!Object.prototype.hasOwnProperty.call(reqBody, field)) return false;
    return String(reqBody[field] ?? '') !== String(previousTask[field] ?? '');
  });
}

function startServer(port = 3741) {
  ensureDatabase();

  const app = express();

  app.use(cors());
  app.use(express.json({ limit: '2mb' }));
  app.use(express.static(path.join(__dirname, 'public')));

  app.get('/api/health', (req, res) => {
    res.json({ ok: true });
  });

  app.post('/api/auth/register', async (req, res) => {
    const { name, username, password } = req.body;

    if (!name || !username || !password) {
      return res.status(400).json({
        error: 'Συμπλήρωσε όνομα, username και password.'
      });
    }

    const db = readDb();
    const normalizedUsername = String(username).trim().toLowerCase();

    if (db.users.some((u) => u.username === normalizedUsername)) {
      return res.status(409).json({
        error: 'Υπάρχει ήδη χρήστης με αυτό το username.'
      });
    }

    const user = {
      id: Date.now(),
      name: String(name).trim(),
      username: normalizedUsername,
      passwordHash: await bcrypt.hash(password, 10),
      createdAt: new Date().toISOString()
    };

    db.users.push(user);
    writeDb(db);

    const token = jwt.sign(
      { id: user.id, name: user.name, username: user.username },
      JWT_SECRET,
      { expiresIn: '12h' }
    );

    res.json({
      token,
      user: { id: user.id, name: user.name, username: user.username }
    });
  });

  app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;

    const db = readDb();
    const normalizedUsername = String(username || '').trim().toLowerCase();
    const user = db.users.find((u) => u.username === normalizedUsername);

    if (!user) return res.status(401).json({ error: 'Λάθος username ή password.' });

    const ok = await bcrypt.compare(password || '', user.passwordHash);
    if (!ok) return res.status(401).json({ error: 'Λάθος username ή password.' });

    const token = jwt.sign(
      { id: user.id, name: user.name, username: user.username },
      JWT_SECRET,
      { expiresIn: '12h' }
    );

    res.json({
      token,
      user: { id: user.id, name: user.name, username: user.username }
    });
  });

  app.get('/api/tasks', authMiddleware, (req, res) => {
    const db = readDb();

    const tasks = db.tasks.sort((a, b) =>
      String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
    );

    res.json(tasks);
  });

  app.post('/api/tasks', authMiddleware, (req, res) => {
    const db = readDb();

    const task = {
      id: Date.now(),
      ...req.body,
      isNew: true,
      createdBy: req.user.name,
      createdById: req.user.id,
      createdAt: new Date().toISOString(),
      updatedAt: null,
      updatedBy: null
    };

    db.tasks.push(task);
    writeDb(db);

    res.json(task);
  });

  app.patch('/api/tasks/:id', authMiddleware, (req, res) => {
    const db = readDb();
    const id = Number(req.params.id);
    const index = db.tasks.findIndex((t) => t.id === id);

    if (index === -1) {
      return res.status(404).json({ error: 'Δεν βρέθηκε η εργασία.' });
    }

    const previousTask = db.tasks[index];
    const statusChanged =
      Object.prototype.hasOwnProperty.call(req.body, 'status') &&
      req.body.status !== previousTask.status;

    const meaningfulChange = isMeaningfulChange(req.body, previousTask);

    db.tasks[index] = {
      ...previousTask,
      ...req.body,
      isNew: statusChanged ? false : previousTask.isNew,
      updatedAt: meaningfulChange ? new Date().toISOString() : previousTask.updatedAt || null,
      updatedBy: meaningfulChange ? req.user.name : previousTask.updatedBy || null
    };

    writeDb(db);
    res.json(db.tasks[index]);
  });

  app.delete('/api/tasks/:id', authMiddleware, (req, res) => {
    const db = readDb();
    const id = Number(req.params.id);

    db.tasks = db.tasks.filter((t) => t.id !== id);
    writeDb(db);

    res.json({ ok: true });
  });

  return new Promise((resolve, reject) => {
    const server = app.listen(port, '0.0.0.0', () => resolve(server));
    server.on('error', reject);
  });
}

function stopServer(server) {
  return new Promise((resolve) => {
    if (!server) return resolve();
    server.close(() => resolve());
  });
}

module.exports = { startServer, stopServer };

if (require.main === module) {
  startServer(3741).then(() => {
    console.log('Seaman Support server running on http://localhost:3741');
  });
}
