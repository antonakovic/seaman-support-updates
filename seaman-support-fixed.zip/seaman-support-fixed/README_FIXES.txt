SEAMAN SUPPORT - FIXED BUILD PACKAGE

ΠΕΡΙΕΧΕΙ:
- server.js με fix για το updatedAt:
  Η τελευταία επεξεργασία αλλάζει μόνο όταν γίνεται πραγματική αλλαγή στα στοιχεία εργασίας.
- package.json με έτοιμο script build-win για NSIS installer.

ΣΗΜΑΝΤΙΚΟ:
Δεν περιλαμβάνεται ο φάκελος public, επειδή δεν μου ανέβηκε εδώ.
Για πλήρες πρόγραμμα, κάνε αντιγραφή αυτόν τον φάκελο πάνω στο δικό σου project ή βάλε μέσα τον δικό σου public φάκελο.

ΒΗΜΑΤΑ:
1. Κράτα backup το υπάρχον project.
2. Αντικατάστησε στο project σου:
   - server.js
   - package.json
3. Βεβαιώσου ότι υπάρχουν οι φάκελοι:
   - public
   - data
4. Τρέξε:
   npm install
   npm run build-win

ΤΕΛΙΚΟ ΑΡΧΕΙΟ:
Το installer θα βγει μέσα στο dist.
